const http = require('http');
const fs = require('fs');
const path = require('path');
const { WebSocketServer, WebSocket } = require('ws');
const crypto = require('crypto');
const PORT = process.env.PORT || 8080;
const GAME_FILE = path.join(__dirname, 'MAXI_STRIKE_PLAYABLE_BATTLEFIELD.html');
const server = http.createServer((req, res) => {
  if (req.url === '/health' || req.url === '/status') {
    res.writeHead(200, { 'content-type': 'application/json; charset=utf-8' });
    res.end(JSON.stringify({ game: 'MAXI STRIKE', status: 'online', players: players.size }));
    return;
  }
  if (req.url === '/' || req.url.startsWith('/index.html')) {
    fs.readFile(GAME_FILE, (err, data) => {
      if (err) {
        res.writeHead(500, { 'content-type': 'text/plain; charset=utf-8' });
        res.end('MAXI STRIKE game file missing. Add MAXI_STRIKE_PLAYABLE_BATTLEFIELD.html to the repository.');
        return;
      }
      res.writeHead(200, { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-cache' });
      res.end(data);
    });
    return;
  }
  res.writeHead(404, { 'content-type': 'application/json; charset=utf-8' });
  res.end(JSON.stringify({ error: 'Not found', game: 'MAXI STRIKE' }));
});
const wss = new WebSocketServer({ server });
const players = new Map();
function broadcast(payload, except) {
  const data = JSON.stringify(payload);
  for (const [client] of players) {
    if (client !== except && client.readyState === WebSocket.OPEN) client.send(data);
  }
}
wss.on('connection', (ws) => {
  const id = crypto.randomUUID();
  ws._maxiId = id;
  ws._maxiPlayer = { id, name: 'Player', x: 0, z: 7, yaw: 0 };
  ws.on('message', (raw) => {
    let msg; try { msg = JSON.parse(raw.toString()); } catch { return; }
    if (!msg || typeof msg.type !== 'string') return;
    if (msg.type === 'join') {
      const name = typeof msg.name === 'string' ? msg.name.trim().slice(0, 16) : 'Player';
      ws._maxiPlayer.name = name || 'Player';
      const existing = [...players.values()];
      players.set(ws, ws._maxiPlayer);
      ws.send(JSON.stringify({ type: 'welcome', id, count: players.size, players: existing }));
      broadcast({ type: 'playerJoined', player: ws._maxiPlayer, count: players.size }, ws);
      return;
    }
    if (msg.type === 'state' && players.has(ws)) {
      const num = (v, fallback) => Number.isFinite(Number(v)) ? Math.max(-110, Math.min(110, Number(v))) : fallback;
      ws._maxiPlayer.x = num(msg.x, ws._maxiPlayer.x);
      ws._maxiPlayer.z = num(msg.z, ws._maxiPlayer.z);
      ws._maxiPlayer.yaw = num(msg.yaw, ws._maxiPlayer.yaw);
      if (typeof msg.name === 'string') ws._maxiPlayer.name = msg.name.trim().slice(0, 16) || 'Player';
      broadcast({ type: 'state', ...ws._maxiPlayer }, ws);
    }
  });
  ws.on('close', () => {
    const existed = players.delete(ws);
    if (existed) broadcast({ type: 'playerLeft', id, count: players.size });
  });
  ws.on('error', () => {});
});
server.listen(PORT, '0.0.0.0', () => console.log(`MAXI STRIKE server listening on ${PORT}`));
