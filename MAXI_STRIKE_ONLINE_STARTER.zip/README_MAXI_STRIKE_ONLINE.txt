MAXI STRIKE — ONLINE STARTER (LANDSCAPE + MULTIPLAYER PRESENCE)

FILES TO PUT IN ONE GITHUB REPOSITORY
- MAXI_STRIKE_PLAYABLE_BATTLEFIELD.html
- maxi-strike-server.js
- package.json
- README_MAXI_STRIKE_ONLINE.txt (optional)

WHAT THIS VERSION DOES
- Serves the game page at the web service root (/).
- Provides a health/status response at /health.
- Supports WebSocket connections for real players' presence and position updates.
- The game pre-fills its own secure WebSocket address when served from HTTPS.
- Requests fullscreen/landscape when supported by the phone browser.

DEPLOY WITH A NODE WEB-SERVICE HOST
1. Create a GitHub repository named maxi-strike-online.
2. Upload the three required files above (plus this README if desired) to the repository root. Do not upload only the ZIP; extract it first.
3. In your hosting dashboard, create a new Web Service and connect the repository.
4. Runtime/language: Node.
5. Build command: npm install
6. Start command: npm start
7. Deploy, then open the public HTTPS address provided by the host. Tap CONNECT ONLINE; the game should prefill the matching wss:// address.
8. Open the same public game URL on another device/browser and tap CONNECT ONLINE to test seeing each other's avatars.

IMPORTANT LIMITS
This is an early online foundation, not a complete multiplayer battle royale. It synchronizes player presence and positions only. Combat results, health, vehicles, pickups, safe-zone state, matchmaking, anti-cheat, and voice chat are not shared/authoritative yet. The free hosting plan may sleep when idle, and landscape/fullscreen support depends on browser/device. Never share account passwords or verification codes.

LOCAL STATUS ENDPOINT
The server listens on process.env.PORT (or 8080 locally). /health returns JSON with current connected-player count.
